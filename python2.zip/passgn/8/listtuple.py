#Implement a program to create a list with two tuple of fruits and vegetables. Access fruits separately and vegetables separately. 
tuplefruits=('apple','banana','chikoo','strawberry',)
print(tuplefruits)
tuplevegetables=('tomato','brinjal','onion','carrot')
print(tuplevegetables)
mylist=list(zip(tuplefruits,tuplevegetables))
print(mylist)

