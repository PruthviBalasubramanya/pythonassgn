#Implement a  program to check the elements in the list has word "SOIS"
list=['hello','how','is','sois','?']
print('sois' in list)
