str1=input("enter the string")
count=0
for i in str1:
	if(i=='a' or i=='A' or i=='e' or i=='E' or i=='i' or i=='I' or i=='o' or i=='O' or i=='u' or i=='U'):
		count=count+1
	print("the number of vowels are:")
	print(count)
