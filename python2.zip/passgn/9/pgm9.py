#Implement a program to create a dictionary of students with Registration number and names. Perform the two operations, insert and delete. 
dict1={'regnum':'101' , 'name':'sam'}
dict2={'regnum':'102','name':'robin'}
dict3={'regnum':'103','name':'sachin'}
#dict4={'regnum':'104','name':'rohit'}
#insert
print(dict1)
print(dict2)
print(dict3)
dict1['marks']='45'
print(dict1)
#delete
del dict2['name']
print(dict2)



