#32. Implement a program to check the total number of students. (create a sample file with RegNo, StudentName, Branch)
import csv
import sys
counter=0
f=open("details.csv",'r')
line=csv.reader(f)
for row in line:
	counter=counter+1
	print(row)
print("total number of students are:",counter)