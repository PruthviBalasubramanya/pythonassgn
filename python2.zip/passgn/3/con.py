#concatenate two strings

str1=input("enter the first string:")
str2=input("enter the second string:")
concatenate=str1+str2
print(concatenate)
