#Create a list with 5 branches in SOIS. Try to do the following operations a) append b) insert c) sort d) reverse sort 
SOIS=['ewt','vir','vlsi','iot','cloud']
new_sois=['networking']
#append


SOIS.append(new_sois)
print("updated SOIS list:",SOIS)
#insert
SOIS=['ewt','vir','vlsi','iot','cloud']
SOIS.insert(4, 'cs')
print("inserted SOIS list:",SOIS)
#sort
SOIS=['ewt','vir','vlsi','iot','cloud']
SOIS.sort();
print("sorted list:",SOIS)
#reverse
SOIS=['ewt','vir','vlsi','iot','cloud']
SOIS.reverse()
print("the reversed SOIS list:",SOIS)


