#16. Implement a program to get three values from CLA and print the sum of them.
import sys
 
# add two integers and return the sum
def add(a, b):
    return a + b
 
 
def main(argv):
 
    # make sure there are at least two arguments
    if len(argv) >= 2:
        # convert arg 0 and 1 to int and pass them to add function
        print ('\n Sum of two numbers is :', add(int(argv[0]), int(argv[1])), '\n')
    
        sys.exit(2)
 
 
if __name__ == '__main__':
 
    # exclude script name from the argumemts list and pass it to main()
    main(sys.argv[1:])
 
