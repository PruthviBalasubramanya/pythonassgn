readfile=open("read.txt","r")
print(readfile.readlines())