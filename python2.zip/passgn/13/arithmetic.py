#Implment a program with arithmetic functions with  case statements.
def add(a, b): 
    return a + b  
  
# Function to subtract two numbers  
def subtract(a, b): 
    return a-b 
  
# Function to multiply two numbers 
def multiply(a,b): 
    return a*b
  
# Function to divide two numbers 
def divide(a,b): 
    return a/b
  
print("Please select operation -\n"
        "1. Add\n" 
        "2. Subtract\n"  
        "3. Multiply\n"  
        "4. Divide\n") 
  
  
choice=input("enter the choice 1,2,3,4")
a=int(input('enter the first number'))
b=int(input('enter the second number'))
if choice=='1':
    print(a ,'+', b, '=', add(a,b))
elif choice=='2':
    print(a, '-', b, '=',subtract(a,b))
elif choice=='3':
    print(a, '*', b,'=',multiply(a,b))
elif choice=='4':
    print(a, '/', b, '=',divide(a,b))
else:
    print("entered choice is wrong")
    
    
