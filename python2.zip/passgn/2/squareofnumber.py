num=int(input("enter the number that has to be squared"))
square=num*num
print(square)
