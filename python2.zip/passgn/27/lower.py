x=input("enter the word:")
lower=""
for i in x:
	if ord(i)>=65 and ord(i)<=90:
		y=ord(i)+32;
		z=chr(x);
		lower=lower+y;
		print(lower)