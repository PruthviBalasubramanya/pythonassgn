#Implement a program to print the elements of a list.
list1=['car','bus','train']
list2=[1,4,3,6,8,2,5]
print(list1[1],list1[0])
print(list2[0:4],list2[3:6])