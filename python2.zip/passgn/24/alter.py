file1=open("alter.txt","r")
print(file1[0:100:2])