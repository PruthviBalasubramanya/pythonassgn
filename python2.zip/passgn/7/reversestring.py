string=str(input("enter the string that has to be reversed:"))
print("the reversed string is :", string)
print(string[::-1])


