import  sys
a=argv[1]
file=open("filewrite1.txt","w")
file.write(a)