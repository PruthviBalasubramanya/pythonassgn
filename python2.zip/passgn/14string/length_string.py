string=input('enter the string')
counter=0
for i in string:
    counter=counter+1 
print(string)
print(counter)
