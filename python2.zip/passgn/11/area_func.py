#find the area of circle triangle and square
def areaofcircle(r):
    PI=3.142
    return PI * (r*r);
print("the area of circle is %.3f "%areaofcircle(5));

#find the area of triangle
def areaoftriangle(b,h):
    return 0.5 *( b*h)
print("the area of triangle is %f" %areaoftriangle(3,4));

#find the are of square
def areaofsquare(a):
    return a*a
print("the areaof square is %f " %areaofsquare(4.4));
    
   
