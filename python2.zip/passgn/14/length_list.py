#find the length of list using stdlib func
list=['apple','banana','tomato','food']
counter=0
for i in list:
    counter=counter+1;
print(list)
print(counter)
