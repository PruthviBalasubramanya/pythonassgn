#Implement a program with lamda functions, for finding the area of circle, triangle, square.
#lambda_circle
PI=3.142
area=lambda r:PI*r*r 
print(area(3))
#lambda_triangle
area1=lambda b,h:0.5*b*h
print(area1(6,7))
#lambda_square
area2=lambda s:s*s
print(area2(3))
