x=int(input("Enter the  number:"))
temp=x
reverse=0
while(x>0):
    digit=x%10
    reverse=reverse*10+digit
    x=x/10
if(temp==reverse):
    print("The number is a palindrome!")
else:
	print("The number isn't a palindrome!")
