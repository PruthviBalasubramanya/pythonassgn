x=input('Please insert a word')
y=reversed(x)
if x==y:
    print('Is a palindrome')
else:
    print('Is not a palindrome')
