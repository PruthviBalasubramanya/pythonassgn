"""the menubased calculator"""

# two numbers to be entered !!
num1=int(input("enter the first number"))
num2=int(input("enter the second number"))

#addition

print('{}+{}=' .format(num1,num2))
print(num1+num2)

#subtraction

print('{}-{}=' .format(num1,num2))
print(num1-num2)

#division

print('{}/{}=' .format(num1,num2))
print(num1/num2)

#multiplication
print('{}*{}=' .format(num1,num2))
print(num1*num2)



