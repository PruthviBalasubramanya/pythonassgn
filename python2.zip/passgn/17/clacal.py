import sys
    a=sys.argv[1]
    b=sys.argv[2]
    c=sys.argv[3]
if(b== '+'):
    print("sum is:",int(a)+int(c))
elif(b=='-'):
    print("difference is:",int(a)-int(c))
elif(b=='*'):
    print("product is:",int(a)*int(c))
elif(b=='/'):
    print("division is:",int(a)/int(c))
elif(b=='%'):
    print("modulus is:",int(a)%int(c))
else:
    print("enter valid operator")